void menu(){

    printf("these are choices:\n");
    printf("1-see menu\n");
    printf("2-minefield(not minesweeper)\n");
    printf("3-snake\n");
    printf("4-stats\n");
    printf("5-save the game\n");
    printf("6-exit program!\n");
    printf("7-increase the points\n");
    printf("8-reset game\n");
    printf("Developer Note:If you want to transfer your game point to your character point, you must save the game.\n\n\n");
}